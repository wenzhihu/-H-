#ifndef __usart_H
#define __usart_H

#include "system.h" 


void USART1_Init(u32 bound);
void Usart_Mes(uint8_t kinda,uint8_t frea,uint8_t phase,uint8_t kindb,uint8_t freb);

#endif


